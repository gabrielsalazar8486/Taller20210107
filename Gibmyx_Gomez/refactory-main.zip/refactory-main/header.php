<?php

echo"
<center>
    <h1>Taller Medine - 28/10/2020</h1>
</center>
";
exit;