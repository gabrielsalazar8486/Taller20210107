<?php

namespace App\Refactory;

use App\DB\ApiService;

class Refactory_1
{
    public function execute()
    {
        return [];
    }

}