<?php

declare(strict_types=1);

namespace App\Refactory;

use App\Object\Cargo;
use App\Object\Orden;

class Refactory_3
{
    public function execute()
    {
        return 0;
    }
}