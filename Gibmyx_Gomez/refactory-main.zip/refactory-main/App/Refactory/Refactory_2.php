<?php

namespace App\Refactory;

use Exception;

class Refactory_2
{
    public function execute()
    {
    }
}