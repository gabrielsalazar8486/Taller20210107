<?php
require_once 'vendor/autoload.php';
require_once 'header.php';
require_once 'Examples/Example1.php';
require_once 'Examples/Example2.php';
require_once 'Examples/Example3.php';
















